import torch
import numpy as np
import torch.utils.data as data
from os import listdir
import os
from PIL import Image
import random
import torchvision


def default_loader(path):
    return Image.open(path).convert('RGB')

class TinyImageNet(data.Dataset):
    def __init__(self, train_root, size=64):
        super(TinyImageNet, self).__init__()
        self.image_list = []
        folders = [x for x in os.listdir(train_root) if os.path.isdir(os.path.join(train_root, x))]
        for folder in folders:
            subpath = os.path.join(train_root, folder, 'images')
            names = [x for x in os.listdir(subpath) if x.endswith('JPEG')]
            for name in names:
                image_name = os.path.join(subpath, name)
                self.image_list.append(image_name)
        self.size = size

    def __getitem__(self, index):
        path = self.image_list[index]
        img = default_loader(path)
        img = img.resize((self.size, self.size))
        # img = ToTensor(img)
        trans = torchvision.transforms.ToTensor()
        img = trans(img)
        norm = torchvision.transforms.Normalize(mean=(0.5,0.5,0.5), std=(0.5,0.5,0.5))
        # img = img.mul_(2).add_(-1)
        img = norm(img)
        return img, img

    def __len__(self):
        return len(self.image_list)


def ToTensor(pic):
    """Converts a PIL.Image or numpy.ndarray (H x W x C) in the range
    [0, 255] to a torch.FloatTensor of shape (C x H x W) in the range [0.0, 1.0].
    """
    if isinstance(pic, np.ndarray):
        # handle numpy array
        img = torch.from_numpy(pic.transpose((2, 0, 1)))
        # backard compability
        return img.float().div(255)
    # handle PIL Image
    if pic.mode == 'I':
        img = torch.from_numpy(np.array(pic, np.int32, copy=False))
    elif pic.mode == 'I;16':
        img = torch.from_numpy(np.array(pic, np.int16, copy=False))
    else:
        img = torch.ByteTensor(torch.ByteStorage.from_buffer(pic.tobytes()))
    # PIL image mode: 1, L, P, I, F, RGB, YCbCr, RGBA, CMYK
    if pic.mode == 'YCbCr':
        nchannel = 3
    elif pic.mode == 'I;16':
        nchannel = 1
    else:
        nchannel = len(pic.mode)
    img = img.view(pic.size[1], pic.size[0], nchannel)
    # put it from HWC to CHW format
    # yikes, this transpose takes 80% of the loading time/CPU
    img = img.transpose(0, 1).transpose(0, 2).contiguous()
    if isinstance(img, torch.ByteTensor):
        return img.float().div(255)
    else:
        return img


# You should build custom dataset as below.
class CelebA(data.Dataset):
    def __init__(self, root='/home/yxgong/ST3/Resources/Public_Data/CelebA', size=32):
        super(CelebA, self).__init__()
        # list all images into a list
        list_path = os.path.join(root, 'Eval', 'list_eval_partition.txt')
        list_file = open(list_path, 'r')
        self.image_list = []
        for line in list_file:
            items = line.split()
            assert items.__len__() == 2
            if items[1] == '0':
                self.image_list.append(items[0][:-3]+'png')
        self.image_path = os.path.join(root, 'Img', 'img_align_celeba_png', 'img_align_celeba_png')
        self.size = size

    def __getitem__(self, index):
        path = os.path.join(self.image_path, self.image_list[index])
        img = default_loader(path)
        img = img.resize((self.size, self.size))
        # img = ToTensor(img)
        trans = torchvision.transforms.ToTensor()
        img = trans(img)
        norm = torchvision.transforms.Normalize([0.5], [0.5])
        # img = img.mul_(2).add_(-1)
        img = norm(img)
        return img, img

    def __len__(self):
        return len(self.image_list)

