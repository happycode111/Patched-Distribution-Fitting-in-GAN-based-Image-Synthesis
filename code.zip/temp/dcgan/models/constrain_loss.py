from torchvision import models
import torch
import torch.nn as nn
import math


class Vgg19(nn.Module):
    def __init__(self, requires_grad=False):
        super(Vgg19, self).__init__()
        vgg_pretrained_features = models.vgg19(pretrained=True).features
        self.slice1 = torch.nn.Sequential()
        self.slice2 = torch.nn.Sequential()
        self.slice3 = torch.nn.Sequential()
        self.slice4 = torch.nn.Sequential()
        self.slice5 = torch.nn.Sequential()
        for x in range(2):
            self.slice1.add_module(str(x), vgg_pretrained_features[x])
        for x in range(2, 7):
            self.slice2.add_module(str(x), vgg_pretrained_features[x])
        for x in range(7, 12):
            self.slice3.add_module(str(x), vgg_pretrained_features[x])
        for x in range(12, 21):
            self.slice4.add_module(str(x), vgg_pretrained_features[x])
        for x in range(21, 30):
            self.slice5.add_module(str(x), vgg_pretrained_features[x])
        if not requires_grad:
            for param in self.parameters():
                param.requires_grad = False

    def forward(self, x):
        h_relu1 = self.slice1(x)
        h_relu2 = self.slice2(h_relu1)
        h_relu3 = self.slice3(h_relu2)
        h_relu4 = self.slice4(h_relu3)
        h_relu5 = self.slice5(h_relu4)
        out = [h_relu1, h_relu2, h_relu3, h_relu4, h_relu5]
        return out


class DMLoss(nn.Module):
    def __init__(self, num_clusters=25):
        super(DMLoss, self).__init__()
        self.vgg = Vgg19().cuda()
        # self.vgg = nn.DataParallel(self.vgg, device_ids=[0,1,2])
        self.criterion = nn.L1Loss()
        # self.weights = [1.0 / 16.0, 1.0 / 8.0, 1.0 / 4.0, 1.0 / 2.0, 1.0]
        self.num_clusters = num_clusters

    def forward(self, x, y):
        loss_sum = 0
        ori_x_means = x.mean(dim=0).unsqueeze(0)
        ori_y_means = y.mean(dim=0).unsqueeze(0)
        ori_w = x.shape[3]
        ori_max_patch_size = math.ceil(ori_w / 2)
        ori_loss_one_layer = 0
        patch_size = 1
        while True:
            if patch_size > ori_max_patch_size:
                ori_loss_one_layer /= (patch_size - 1)
                break
            patched_x_means = torch.nn.functional.avg_pool2d(input=ori_x_means, kernel_size=patch_size, stride=patch_size)
            patched_y_means = torch.nn.functional.avg_pool2d(input=ori_y_means, kernel_size=patch_size, stride=patch_size)
            ori_loss_one_layer += self.criterion(patched_x_means, patched_y_means)
            patch_size += 1

        loss_sum += ori_loss_one_layer
        x_vggs, y_vggs = self.vgg(x), self.vgg(y)

        for j in range(len(x_vggs)):
            # pixels = x_vggs[j].shape[2] * x_vggs[j].shape[3]
            # x_vgg = self.sort_tensor(x_vggs[j])
            # y_vgg = self.sort_tensor(y_vggs[j])
            # x_vgg = torch.sum(x_vgg, dim=1).squeeze(1)
            # y_vgg = torch.sum(y_vgg, dim=1).squeeze(1)
            # x_max_value = x_vgg.view(-1)[torch.argmax(x_vgg)]
            # y_max_value = y_vgg.view(-1)[torch.argmax(y_vgg)]
            # max_value = x_max_value if x_max_value >= y_max_value else y_max_value
            # x_min_value = x_vgg.view(-1)[torch.argmin(x_vgg)]
            # y_min_value = y_vgg.view(-1)[torch.argmin(y_vgg)]
            # min_value = x_min_value if x_min_value <= y_min_value else y_min_value
            #
            # pixel_range = max_value - min_value
            # interval = pixel_range / self.num_clusters
            # nodes = [min_value + interval * n for n in range(self.num_clusters)]
            # loss = 0
            # zeros = torch.zeros_like(x_vgg)
            # ones = torch.ones_like(x_vgg)
            # for i in range(nodes.__len__() - 1):
            #     # min_tensor = torch.FloatTensor(_input.shape).fill_(nodes[i])
            #     # max_tensor = torch.FloatTensor(_input.shape).fill_(nodes[i+1])
            #
            #
            #     input_mask = self.sort_tensor(torch.where((torch.where(x_vgg >= nodes[i], ones, zeros)
            #                                                + torch.where(x_vgg < nodes[i + 1], ones, zeros)) > 1.001,
            #                                               ones, zeros)).squeeze(1)
            #     target_mask = self.sort_tensor(torch.where((torch.where(y_vgg >= nodes[i], ones, zeros)
            #                                                 + torch.where(y_vgg < nodes[i + 1], ones, zeros)) > 1.001,
            #                                                ones, zeros)).squeeze(1)
            #
            #     diff1 = torch.where(input_mask + target_mask >= 1.001, zeros, ones)
            #     diff2 = torch.where(input_mask + target_mask <= 0.999, zeros, ones)
            #     diff = self.sort_tensor(torch.where(diff1 + diff2 >= 1.001, ones, zeros))
            #
            #     diff_num = torch.sum(diff)
            #     input_num = torch.sum(input_mask)
            #     target_sum = torch.sum(target_mask)
            #
            #     loss_ = torch.clamp(diff_num - 0.5 * min(input_num, target_sum), 0, pixels) / pixels
            #     loss += loss_
            #
            # loss_sum += loss / len(x_vggs)
            loss_one_layer = 0
            x_vgg = x_vggs[j]
            y_vgg = y_vggs[j]

            x_means = x_vgg.mean(dim=0).unsqueeze(0)
            y_means = y_vgg.mean(dim=0).unsqueeze(0)

            # h = x_means.shape[2]
            w = x_means.shape[3]
            if w == 1:
                loss_one_layer += self.criterion(x_means, y_means)
            max_patch_size = math.ceil(w / 2)
            patch_size = 1
            while True:
                if patch_size > max_patch_size:
                    loss_one_layer /= (patch_size - 1)
                    break
                patched_x_means = torch.nn.functional.avg_pool2d(input=x_means, kernel_size=patch_size, stride=patch_size)
                patched_y_means = torch.nn.functional.avg_pool2d(input=y_means, kernel_size=patch_size, stride=patch_size)
                loss_one_layer += self.criterion(patched_x_means, patched_y_means)
                patch_size += 1

            aa = (1 / (2 ** (j + 1)))
            loss_sum += (1/(2**(j+1))) * loss_one_layer

        # loss_sum /= len(x_vggs)

        return loss_sum

    def sort_tensor(self, tensor):
        batch_size = tensor.shape[0]
        nc = tensor.shape[1]
        if tensor.shape.__len__() == 4:
            h = tensor.shape[2]
            w = tensor.shape[3]

            tensor = tensor.view(batch_size, nc, h*w)

        if tensor.shape.__len__() == 3:
            c = tensor[:, 0, :]
            c_sorted, indices = torch.sort(c, 1)
            tensor_sorted = c_sorted.unsqueeze(1)
            for i in range(1, nc):
                c = tensor[:, i, :]
                c_sorted, indices = torch.sort(c, 1)
                tensor_sorted = torch.cat((tensor_sorted, c_sorted.unsqueeze(1)), 1)
        else:
            c_sorted, indices = torch.sort(tensor, 1)
            tensor_sorted = c_sorted.unsqueeze(1)

        # c1 = tensor[:, 0, :]
        # if self.colored:
        #     c2 = tensor[:, 1, :]
        #     c3 = tensor[:, 2, :]
        #
        # c1_sorted, indices = torch.sort(c1, 1)
        # _, indices = torch.sort(indices)
        #
        # if self.colored:
        #     c2_sorted = self.sort_from_indices(c2, indices)
        #     c3_sorted = self.sort_from_indices(c3, indices)
        #
        # tensor_sorted = c1_sorted.unsqueeze(1)
        # if self.colored:
        #     tensor_sorted = torch.cat((tensor_sorted, c2_sorted.unsqueeze(1)), 1)
        #     tensor_sorted = torch.cat((tensor_sorted, c3_sorted.unsqueeze(1)), 1)

        return tensor_sorted
