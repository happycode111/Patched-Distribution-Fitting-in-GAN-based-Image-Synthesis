import random

import torch
import numpy as np
import math
import torch.nn.functional as F

def calc_kldiv(gen_dis_file_root=None, times=10):
    real_dist = []
    for i in range(1000):
        real_dist.append(25.6)
    real_tensor = torch.Tensor(real_dist)
    # real_dis_file_root = '/home/yxgong/ST3/Codes/2021-GLGAN/results/real/distribution.txt'
    # real_dis_file = open(real_dis_file_root, 'r')
    # for i in range(1000):
    #     real_dist.append(0)
    # for j, line in enumerate(real_dis_file):
    #     items = line.split(',')
    #     if items.__len__() != 3:
    #         print("Error in real distribution! Line %d" % j)
    #         continue
    #     a = int(items[0])
    #     b = int(items[1])
    #     c = int(items[2])
    #     mode = 100 * a + 10 * b + c
    #     real_dist[mode] += 1
    # real_tensor = torch.Tensor(real_dist)
    # real_tensor = real_tensor / torch.sum(real_tensor)

    kl_values = []
    # gen_dis_file_root = './results/generated/ldf1o2_b128_utest_a5e-2/'
    for i in range(times):
        print('\rCalculating %d-th KL divergence.' % i, end='', flush=True)
        file_name = gen_dis_file_root + '/trial_' + str(i) + '/distribution.txt'
        gen_dis_file = open(file_name, 'r')
        gen_dist = []
        for i in range(1000):
            gen_dist.append(0)
        for j, line in enumerate(gen_dis_file):
            items = line.split(',')
            if items.__len__() != 3:
                print("Error in gen distribution! Number %d Line %d" % (i, j))
                continue
            a = int(items[0])
            b = int(items[1])
            c = int(items[2])
            mode = 100 * a + 10 * b + c
            gen_dist[mode] += 1
        gen_tensor = torch.Tensor(gen_dist)
        # gen_tensor = gen_tensor / torch.sum(gen_tensor)

        kl_value = torch.nn.functional.kl_div(F.log_softmax(gen_tensor), F.softmax(real_tensor), reduction='mean')
        print('KL value %d', float(kl_value))
        kl_values.append(float(kl_value))

    kls = torch.Tensor(kl_values)
    mean = kls.mean()
    std = kls.std()
    se = std / np.sqrt(times)

    # print(mean, std, se)
    return mean, std, se


if __name__ == '__main__':
    times=10
    out_path = 'results_patched_bs_128'
    mean, std, se = calc_kldiv(gen_dis_file_root='../../results/%s/' % out_path, times=times)
    print(mean, std, se)
