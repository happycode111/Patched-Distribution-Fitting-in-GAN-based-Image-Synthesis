# import theano

from scipy import misc
import numpy

import warnings
warnings.filterwarnings('ignore')

import os
# os.environ['KERAS_BACKEND']='theano'
from tensorflow import keras

# keras.backend.set_image_dim_ordering('th')

os.environ["TF_CPP_MIN_LOG_LEVEL"]='2'

def evaluate(x, model):

    output = model(x)

    return list(numpy.argmax(output, axis=1))


def calc_modes(times=0, path=None):
    if path is None:
        path = '../results/generated/gdf1o1/0/'
    results_txt = open(path + '/distribution.txt', 'w+')
    # p2 = numpy.reshape(misc.imread("4.jpg"), (1, 28, 28, 1))
    # p9 = numpy.reshape(misc.imread("83.jpg"), (1, 28, 28, 1))
    # p3 = numpy.reshape(misc.imread("107.jpg"), (1, 28, 28, 1))
    # path = '/home/yxgong/ST3/Codes/2021-GLGAN/unrolledgantest/generated/gdf1o2/0/'
    list_ = [x for x in os.listdir(path) if os.path.isdir(os.path.join(path, x))]

    recorder = []
    # r = 0
    model = keras.models.load_model("val_methods/mnist_model.hdf5")
    for i, folder in enumerate(list_):
        if folder == 'for_kl':
            continue
        if i % 10 == 0:
            print('\rTesting %d-th experiment [%d/%d]' % (times, i, 25600), end='', flush=True)
        subpath = os.path.join(path, folder)
        img1_path = os.path.join(subpath, '1.png')
        img2_path = os.path.join(subpath, '2.png')
        img3_path = os.path.join(subpath, '3.png')
        a = misc.imread(img1_path, mode='L')
        img1 = numpy.reshape(a, (1, 28, 28, 1))
        img2 = numpy.reshape(misc.imread(img2_path, mode='L'), (1, 28, 28, 1))
        img3 = numpy.reshape(misc.imread(img3_path, mode='L'), (1, 28, 28, 1))
        # print(evaluate(numpy.concatenate((img1, img2, img3), axis = 0)))
        result = evaluate(numpy.concatenate((img1, img2, img3), axis=0), model)
        assert len(result) == 3
        a = 100 * int(result[0])
        b = 10 * int(result[1])
        c = int(result[2])
        r = a + b + c
        if not (r in recorder):
            recorder.append(r)
        results_txt.write(str(int(result[0]))+','+str(int(result[1]))+','+str(int(result[2]))+'\n')

    del model
    # print('Modes generated: ', recorder.__len__())
    results_txt.close()
    return recorder.__len__()


if __name__ == '__main__':
    root = '/home/yxgong/ST3/Codes/2021-GLGAN/Check/Paper5107_Supplementary_Material/stacked_mnist/'
    modes_list = []
    for i in range(1):
        folder = str(i+1)
        path = os.path.join(root, folder)
        modes_list.append(calc_modes(times=i, path=path))
    print(modes_list)
