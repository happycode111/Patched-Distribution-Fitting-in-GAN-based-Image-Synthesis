import numpy as np

modes = np.array([954,31,38,964,28,27,22,41,967,33])
mean = modes.mean()
std = modes.std()
se = std / np.sqrt(10)

print(mean, se)