import argparse
import os
import numpy as np
from constrain_loss_patch import DMLoss

from torchvision.utils import save_image

from torch.utils.data import DataLoader
from torch.autograd import Variable

import torch.nn as nn
import torch
from dataset import StackedMNIST

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

os.makedirs("images", exist_ok=True)
os.makedirs("models", exist_ok=True)
os.makedirs("models/checkpoints", exist_ok=True)

parser = argparse.ArgumentParser()
parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")
parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
parser.add_argument("--batch_size", type=int, default=128, help="size of the batches")
parser.add_argument("--channels", type=int, default=3, help="number of image channels")
parser.add_argument("--img_size", type=int, default=28, help="size of each image dimension")
parser.add_argument("--latent_dim", type=int, default=256, help="dimensionality of the latent space")
parser.add_argument("--lr", type=float, default=0.0002, help="adam: learning rate")
parser.add_argument("--method", type=str, default='patched',
                    help="method to suppress mode collapse: none, ttest or utest")
parser.add_argument("--n_cpu", type=int, default=10, help="number of cpu threads to use during batch generation")
parser.add_argument("--n_epochs", type=int, default=200, help="number of epochs of training")
parser.add_argument("--sample_interval", type=int, default=400, help="interval between image samples")
opt = parser.parse_args()
print(opt)

img_shape = (opt.channels, opt.img_size, opt.img_size)

cuda = True if torch.cuda.is_available() else False


class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()

        self.init_size = opt.img_size // 7
        self.l1 = nn.Sequential(nn.Linear(opt.latent_dim, 64 * self.init_size ** 2))

        self.conv_blocks = nn.Sequential(
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, 3, 2, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.ConvTranspose2d(32, 16, 3, 2, 1, 1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.ConvTranspose2d(16, 8, 3, 2, 1, 1),
            nn.BatchNorm2d(8),
            nn.ReLU(),
            nn.Conv2d(8, opt.channels, 3, stride=1, padding=1),
            nn.Tanh(),
        )

    def forward(self, z):
        out = self.l1(z)
        out = out.view(out.shape[0], 64, self.init_size, self.init_size)
        img = self.conv_blocks(out)
        return img


class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        X = 1

        def discriminator_block(in_filters, out_filters, bn=True):
            block = [nn.Conv2d(in_filters, out_filters, 3, 2, 1), nn.BatchNorm2d(out_filters), nn.LeakyReLU(0.3, inplace=True)]
            return block

        self.model = nn.Sequential(
            *discriminator_block(opt.channels, int(8*X)),
            *discriminator_block(int(8*X), int(16*X)),
            *discriminator_block(int(16*X), int(32*X)),
        )

        self.adv_layer = nn.Sequential(nn.Linear(int(32*X)*4*4, 1), nn.Sigmoid())

    def forward(self, img):
        out = self.model(img)
        out = out.view(out.shape[0], -1)
        validity = self.adv_layer(out)

        return validity


adversarial_loss = torch.nn.BCELoss()
df_loss = torch.nn.L1Loss()
dm_loss = DMLoss()

for iii in range(10):
    # Initialize generator and discriminator
    generator = Generator()
    discriminator = Discriminator()

    if cuda:
        generator.cuda()
        discriminator.cuda()
        adversarial_loss.cuda()
        df_loss.cuda()

    datatset = StackedMNIST(size=opt.img_size)
    dataloader = torch.utils.data.DataLoader(dataset=datatset,
                                             batch_size=opt.batch_size,
                                             shuffle=True,
                                             num_workers=opt.n_cpu)

    # Optimizers
    optimizer_G = torch.optim.Adam(generator.parameters(), lr=opt.lr, betas=(opt.b1, opt.b2))
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=opt.lr, betas=(opt.b1, opt.b2))

    Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor

    # ----------
    #  Training
    # ----------
    # avg_times = 0
    # total_mean = torch.FloatTensor([0])
    # total_var = torch.FloatTensor([0])
    # total_std = torch.FloatTensor([0])
    # if cuda:
    #     total_mean = total_mean.cuda()
    #     total_var = total_var.cuda()
    #     total_std = total_std.cuda()

    # dtype = torch.cuda.FloatTensor
    # # feature_extracting = inception_v3(pretrained=True, transform_input=False).type(dtype)
    # feature_extracting = vgg.vgg16(pretrained=True).type(dtype)
    #
    # feature_extracting.eval()
    # inception_up = nn.Upsample(size=(299, 299), mode='bilinear').type(dtype)

    for epoch in range(opt.n_epochs):
        for i, imgs in enumerate(dataloader):
            # Adversarial ground truths
            valid = Variable(Tensor(imgs.size(0), 1).fill_(1.0), requires_grad=False)
            fake = Variable(Tensor(imgs.size(0), 1).fill_(0.0), requires_grad=False)

            # Configure input
            real_imgs = Variable(imgs.type(Tensor))

            # -----------------
            #  Train Generator
            # -----------------

            optimizer_G.zero_grad()

            # Sample noise as generator input
            z = Variable(Tensor(np.random.normal(0, 1, (imgs.shape[0], opt.latent_dim))))

            # Generate a batch of images
            gen_imgs = generator(z)

            # Loss measures generator's ability to fool the discriminator
            g_loss = adversarial_loss(discriminator(gen_imgs), valid)

            # if opt.method == 'ttest' or opt.method == 'utest':
            #     mean = real_imgs.mean(dim=0)
            #     old_total_mean = total_mean
            #     total_mean = ((mean * opt.batch_size) + (total_mean * opt.batch_size * avg_times)) / \
            #                  (opt.batch_size * (avg_times + 1))
            #     reals = real_imgs.clone()
            #     for j in range(imgs.shape[0]):
            #         reals[j, :, :, :] -= total_mean
            #         reals[j, :, :, :] = reals[j, :, :, :].mul(reals[j, :, :, :])
            #     var = torch.sum(reals, dim=0)
            #     old_total_std = total_std
            #     total_var = (var + (total_var * opt.batch_size * avg_times)) / \
            #                 (opt.batch_size * (avg_times + 1))
            #     total_std = torch.sqrt(total_var)
            #     avg_times += 1
            #
            #     fake_mean = gen_imgs.mean(dim=0)
            #     fake_std = gen_imgs.std(dim=0)
            #
            #     up = fake_mean - total_mean
            #     if opt.method == 'utest':
            #         down = total_std * (1 / math.sqrt(gen_imgs.shape[0]))
            #     else:
            #         down = fake_std * (1 / math.sqrt(gen_imgs.shape[0]))
            #     zero_tensor = torch.zeros_like(up)
            #     one_tensor = torch.ones_like(up)
            #     up = torch.where(down <= 1e-5, zero_tensor, up)
            #     down = torch.where(down <= 1e-5, one_tensor, down)
            #     t = torch.div(up, down)
            #
            #     if opt.method == 'utest':
            #         ht_loss = torch.abs(t) - 1.96
            #     else:
            #         ht_loss = torch.abs(t) - 2.1315
            #
            #     ht_loss = torch.clamp(ht_loss, min=0)
            #     zero_tensor = torch.zeros_like(ht_loss)
            #     ht_loss = torch.where(ht_loss >= 10, zero_tensor, ht_loss)
            #     numel = torch.nonzero(ht_loss).shape[0]
            #     ht_loss = torch.sum(ht_loss) / numel if numel != 0 else torch.cuda.FloatTensor([0])
            #
            #     if epoch >= 1:
            #         g_loss = g_loss + ht_loss

            ht_loss = dm_loss(real_imgs, gen_imgs)

            # real_features = feature_extracting(real_imgs)
            # gen_features = feature_extracting(gen_imgs)
            # # (bs, 512, 1, 1)
            # real_features = torch.sum(real_features, dim=1).squeeze(1).squeeze(1)
            # gen_features = torch.sum(gen_features, dim=1).squeeze(1).squeeze(1)
            #
            # ht_loss1 = kl_loss(torch.nn.functional.log_softmax(real_features),
            #                    torch.nn.functional.softmax(gen_features))
            # ht_loss2 = kl_loss(torch.nn.functional.log_softmax(gen_features),
            #                    torch.nn.functional.softmax(real_features))
            # ht_loss = (ht_loss1 + ht_loss2) / 2
            # kl_value = torch.nn.functional.kl_div(real_features, gen_features, reduction='mean')
            g_loss = g_loss + 1 * ht_loss

            g_loss.backward()
            optimizer_G.step()

            # ---------------------
            #  Train Discriminator
            # ---------------------

            optimizer_D.zero_grad()

            # Measure discriminator's ability to classify real from generated samples
            real_loss = adversarial_loss(discriminator(real_imgs), valid)
            fake_loss = adversarial_loss(discriminator(gen_imgs.detach()), fake)
            d_loss = (real_loss + fake_loss) / 2.

            d_loss.backward()
            optimizer_D.step()
            if i % 10 == 0:
                print(
                    "[Trial %d/%d] [Epoch %d/%d] [Batch %d/%d] [D loss: %f] [G loss: %f] [HT loss: %f]"
                    % (iii, 9, epoch + 1, opt.n_epochs, i, len(dataloader), d_loss.item(), g_loss.item(),
                       ht_loss.item()
                       )
                )

            batches_done = epoch * len(dataloader) + i
            if batches_done % opt.sample_interval == 0:
                save_image(gen_imgs.data[:25], "images/%d.png" % batches_done, nrow=5, normalize=True)

        if epoch % 50 == 0:
            torch.save(generator.state_dict(), 'models/checkpoints/G_%d.pth' % epoch)
            torch.save(discriminator.state_dict(), 'models/checkpoints/D_%d.pth' % epoch)

    torch.save(generator.state_dict(), 'models/G_' + opt.method + '_bs_' + str(opt.batch_size) + '_' + str(iii) + '.pth')
    torch.save(discriminator.state_dict(), 'models/D_' + opt.method + '_bs_' + str(opt.batch_size) + '_' + str(iii) + '.pth')
