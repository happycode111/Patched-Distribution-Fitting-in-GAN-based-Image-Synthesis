import torch
from PIL import Image
import random
import torchvision


class StackedMNIST(torchvision.datasets.MNIST):
    def __init__(self, size=28):
        super(StackedMNIST, self).__init__("./data/mnist", train=True, download=True)
        self.image_list = self.data
        self.size = size

    def __getitem__(self, index):
        rs = [random.randint(0, 59999), random.randint(0, 59999), random.randint(0, 59999)]
        img1 = self.image_list[rs[0]]
        img1 = Image.fromarray(img1.numpy(), mode='L')
        img2 = self.image_list[rs[1]]
        img2 = Image.fromarray(img2.numpy(), mode='L')
        img3 = self.image_list[rs[2]]
        img3 = Image.fromarray(img3.numpy(), mode='L')
        to_tensor = torchvision.transforms.ToTensor()
        img1 = to_tensor(img1)
        img2 = to_tensor(img2)
        img3 = to_tensor(img3)
        img = torch.cat((img1, img2, img3), dim=0)
        norm = torchvision.transforms.Normalize([0.5], [0.5])
        img = norm(img)
        return img

    def __len__(self):
        return len(self.image_list)

